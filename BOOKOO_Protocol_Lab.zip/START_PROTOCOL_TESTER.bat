@echo off
setlocal
cd /d "%~dp0"
title BOOKOO Ultra Protocol Lab

echo =====================================
echo       BOOKOO Ultra Protocol Lab
echo =====================================
echo.
echo Close BOOKOO and Beanconqueror on your phone before continuing.
echo Keep the scale awake and near this computer.
echo.

where py >nul 2>nul
if errorlevel 1 (
    echo Python launcher ^(py^) was not found.
    echo Install Python from python.org and enable the Python launcher.
    echo.
    pause
    exit /b 1
)

set "BOOKOO_PYTHON_EXE="
for /f "delims=" %%I in ('py -c "import sys; print(sys.executable)"') do set "BOOKOO_PYTHON_EXE=%%I"
if not defined BOOKOO_PYTHON_EXE (
    echo The Python launcher could not resolve a Python executable.
    echo.
    pause
    exit /b 1
)

echo Using Python: %BOOKOO_PYTHON_EXE%
echo Checking the Bluetooth library...
"%BOOKOO_PYTHON_EXE%" -c "from bleak import BleakClient, BleakScanner" >nul 2>nul
if errorlevel 1 (
    echo The installed Bleak package is missing or incompatible.
    echo Repairing it now...
    "%BOOKOO_PYTHON_EXE%" -m pip install --upgrade --force-reinstall "bleak>=1.0"
    if errorlevel 1 (
        echo.
        echo Bleak repair failed.
        pause
        exit /b 1
    )

    "%BOOKOO_PYTHON_EXE%" -c "from bleak import BleakClient, BleakScanner" >nul 2>nul
    if errorlevel 1 (
        echo.
        echo Bleak still cannot load the required Bluetooth classes.
        echo Python and package diagnostics:
        "%BOOKOO_PYTHON_EXE%" -c "import sys; print('Python:', sys.executable); import bleak; print('Bleak loaded from:', getattr(bleak, '__file__', 'unknown'))"
        echo.
        echo Check that this folder does not contain bleak.py or a folder named bleak.
        pause
        exit /b 1
    )
)

"%BOOKOO_PYTHON_EXE%" -c "import importlib.metadata as m; import bleak; print('Bleak', m.version('bleak'), 'loaded from', bleak.__file__)"

echo Running offline protocol checks first...
"%BOOKOO_PYTHON_EXE%" bookoo_protocol_lab.py --self-test
if errorlevel 1 (
    echo.
    echo Offline protocol checks failed. Hardware tests were not started.
    pause
    exit /b 1
)

echo.
echo Starting guided hardware tests...
"%BOOKOO_PYTHON_EXE%" bookoo_protocol_lab.py

echo.
echo The tester has finished. Its report is under protocol_sessions.
pause
