BOOKOO Ultra Protocol Lab
=========================

Purpose
-------
Use this tool before adding more functions to the production reader. It tests
whether each documented Bluetooth command actually changes the hardware, and
it records automatic/ratio packets that the current reader misses.

Quick start on Windows
----------------------
1. Put these files beside the existing BOOKOO reader files.
2. Close BOOKOO and Beanconqueror on your phone.
3. Turn on the BOOKOO Ultra scale.
4. Double-click START_PROTOCOL_TESTER.bat.
5. Run the menu tests in order. Run Shutdown last.

The launcher resolves one exact python.exe and uses it for the Bleak check,
package repair, offline checks and hardware tests. This prevents the Windows
Python launcher from switching interpreters when it reads the script shebang.

If Bleak is present but incompatible, the launcher now repairs it automatically.
The equivalent manual repair command is:

    py -m pip install --upgrade --force-reinstall "bleak>=1.0"

If that still fails, check that the test folder does not contain a file named
bleak.py or a subfolder named bleak, because either would hide the real package.

The tool automatically runs connection, GATT and live-stream checks. Each
selected test is saved as PASS, FAIL, INCONCLUSIVE, TRANSPORT_ONLY, BLOCKED, or
NOT_RUN. Successful Bluetooth transmission alone is never reported as a
functional PASS.

Output
------
Every run creates a timestamped folder under protocol_sessions containing:

- raw_packets.csv: every read, write and notification with decoded data
- session_metadata.json: device, platform, BLE version and source version
- gatt_inventory.json: every service, characteristic, property and descriptor
- test_results.json: complete machine-readable test evidence
- test_results.md: short human-readable result table

Important
---------
- Beep, auto-off and flow smoothing are restored after their tests.
- Calibration is gated because BOOKOO publishes the command but not the
  procedure or required reference mass.
- Powder/ratio and shutdown require compatible firmware.
- The public protocol has no command for selecting ratio/automatic/weight mode.
- Live packet weight is always grams, even when the physical display is ounces.

Offline use
-----------
Check protocol fixtures:

    py bookoo_protocol_lab.py --self-test

Analyze an old mapper log without connecting the scale:

    py bookoo_protocol_lab.py --replay protocol_logs/packet_log_YYYYMMDD_HHMMSS.csv

Read BOOKOO_PROTOCOL_AUDIT.md for the evidence map, current defects, unknowns,
and the definition of a complete protocol map.
