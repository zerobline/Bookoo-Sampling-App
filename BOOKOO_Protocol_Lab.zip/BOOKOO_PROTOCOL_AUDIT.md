# BOOKOO Ultra communication audit

Date: 2026-08-29  
Scope: the custom `bookoo_reader.py`, the current `bookoo_protocol_mapper.py`, BOOKOO's official Ultra protocol, and the two captured Drive logs.

## Decision

The project has enough information to establish a BLE connection and run the current weight/timer reader. It does **not** yet have a complete, proven map for every Ultra feature.

- **Basic connection and live measurement:** sufficiently defined.
- **Current batch-reader workflow:** mostly implemented and supported by the published protocol.
- **Automatic mode and ratio mode:** incomplete in the app.
- **All published command and receive formats:** now mapped in the validator.
- **All hardware behavior:** not yet proven; the guided hardware tests must be run.
- **Undocumented “Other Data” and programmatic mode selection:** unavailable in BOOKOO's public source. These require BOOKOO, a capture of the original app, or both.

The important distinction is that a BLE write returning successfully proves only transport. It does not prove that the scale accepted the command in its current mode, that the firmware supports it, or that the physical behavior occurred.

## Evidence used

| Evidence | What it proves | Confidence |
|---|---|---|
| [BOOKOO official `protocols.md`](https://github.com/BooKooCode/OpenSource/blob/main/bookoo_ultra_scale/protocols.md), last updated 2026-08-12, file SHA `8dd75655ba5cb0c7188debd17ceab8f8ba39cf62` | UUIDs, framing, checksum, documented commands, and receive-packet layouts | Official/documented |
| `bookoo_reader.py`, modified 2026-08-29 06:38:13 | What the custom production reader currently uses | Implemented, not necessarily proven |
| `bookoo_protocol_mapper.py`, modified 2026-08-29 06:38:13 | What the first diagnostic tool attempts to map | Implemented with gaps/errors |
| `packet_log_20260829_083835.csv` | Actual traffic from the user's scale | Captured |
| `packet_log_20260829_083818.csv` | Header only; no protocol evidence | None |

The useful capture contains 851 rows over roughly 85 seconds:

- 844 valid live `0x0B` packets on `FF11`;
- one valid automatic-mode `0x0D` “started” event on `FF12`;
- six initial GATT reads;
- approximately 100.7 ms mean live-packet interval, or about 9.9 Hz;
- observed device name `BOOKOO_SC_U 033120`;
- battery 80%, standby setting 15.0 minutes, beep level 1, flow smoothing off, and display-unit code 1 throughout the capture.

## Minimum communication contract

These are the parameters required to establish and use the core connection.

| Layer | Parameter | Value | Evidence | Current state |
|---|---|---:|---|---|
| Transport | Technology | Bluetooth Low Energy / GATT | Official + working capture | Present |
| Discovery | Observed device name | `BOOKOO_SC_U 033120` | Captured | Present, but the app's name filter is brittle |
| Discovery | Primary custom service | `0x0FFE` / `00000ffe-0000-1000-8000-00805f9b34fb` | Official | Present in specification; persist actual GATT inventory on next run |
| Receive | Weight/data characteristic | `0xFF11` / full 128-bit UUID | Official + captured | Used by reader |
| Command/events | Command characteristic | `0xFF12` / full 128-bit UUID | Official + captured | Written by reader; notifications missed by reader |
| Subscribe | Live data | Subscribe to `FF11` notify/indicate | Official + captured | Implemented |
| Subscribe | Auto/ratio events | Subscribe to `FF12` notify/indicate | Captured `0x0D` on `FF12` | Missing in reader |
| Write | Command length | 6 bytes | Official | Implemented |
| Receive | Published packet length | 20 bytes | Official + captured | Only `0x0B` decoded in reader |
| Header | Product byte | `0x03` | Official + captured | Implemented |
| Types | Command/live/auto/powder | `0x0A` / `0x0B` / `0x0D` / `0x0F` | Official | Auto/powder missing in reader |
| Integrity | Checksum | XOR of all preceding packet bytes | Official + captured | Implemented |
| Integer order | Multi-byte fields | Big-endian | Official | Implemented |
| Sign | Weight/flow/result | ASCII `+` (`0x2B`) or `-` (`0x2D`) | Official + captured | Implemented for live data |
| Weight | Live packet scale | unsigned 24-bit × 0.01 g | Official | Implemented |
| Flow/result | Live packet scale | unsigned 16-bit × 0.01 | Official | Implemented |
| Timer | Live packet scale | unsigned 24-bit milliseconds | Official | Implemented |
| MTU | Payload requirement | Published packets are at most 20 bytes | Inference from protocol | No custom MTU is required for these packets |

The next live run must persist exact characteristic properties (`read`, `write`, `write-without-response`, `notify`, `indicate`), advertisement fields, RSSI, and MTU. The old mapper printed some of these but did not save them in its report.

## Receive-packet coverage

| Type | Purpose | Official fields | Captured | Reader | New validator |
|---|---|---|---|---|---|
| `0x0B` | Live scale data | timer, display-unit code, weight in grams, flow, battery, standby minutes, beep level, flow smoothing, reserved byte | Yes, 844 packets | Partial: timer, weight, flow, battery, unit code | Full published decode |
| `0x0D` | Automatic-mode event and settlement | event state, timer, weight, average flow **or** ratio result | Yes, one `started` event on `FF12` | Missing because reader subscribes only to `FF11` | Decoded on any notifying characteristic |
| `0x0F` | Powder-weight readback | sign and powder weight in grams | Not yet captured | Missing | Decoded and explicitly tested |
| Other | BOOKOO private data | Not published | Not captured | Missing | Logged as undocumented, not guessed |

Important corrections:

1. A `0x0B` packet's weight value is **always grams**, even when byte 5 says the scale display is in ounces. The first mapper labels that same numeric value as ounces, which is incorrect.
2. The two-byte standby field should be called `standby_minutes` or `auto-off setting`, not “minutes remaining.” In the real 85-second capture it remained exactly 15.0; the public document does not call it a countdown.
3. Automatic/ratio settlement traffic can arrive on `FF12`. The production reader currently subscribes only to `FF11`, so it cannot see the captured `0x0D` event.

## Command map and proof criteria

`DATA1` below is byte 4 of the complete packet; `DATA2` is byte 5.

| Command | Code | Parameter encoding | Current app | Current mapper | Functional proof required |
|---|---:|---|---|---|---|
| Tare | `0x01` | none | Used | Mapped | Non-zero weight becomes approximately zero |
| Beep level | `0x02` | level 0–5 in **DATA2** | Not used | **Wrong: sends it in DATA1** | Live beep field changes, audible/display behavior matches, original restored |
| Auto-off | `0x03` | 5–30 minutes in DATA2 | Not used | Mapped | Standby field changes, then original restores |
| Start timer | `0x04` | none | Not exposed alone | Mapped | Timer advances |
| Stop timer | `0x05` | none | Used at trial end | Mapped | Timer stops advancing |
| Reset timer | `0x06` | none | Used after stop | Mapped | Timer becomes zero and finished/display state is checked separately |
| Tare + start | `0x07` | none | Used | Mapped | Weight zeroes while timer advances |
| Flow smoothing | `0x08` | 0/1 in DATA1 | Not used | Mapped | Live smoothing field changes and restores |
| Calibrate | `0x09` | none | Not used | Mapped | Must use BOOKOO's calibration procedure and specified mass; do not test blindly |
| Auto stop condition | `0x0B` | 0/1 in DATA1 | Not used | Mapped | Run automatic-mode behavior; no published setting readback exists |
| Set powder weight | `0x0D` | grams × 10, high/low bytes | **Missing** | **Missing** | `0x0F` readback or physical display plus ratio-mode behavior |
| Shutdown | `0x15` | none | Not used | Mapped | Scale powers off and disconnects; requires release firmware ≥4.0.0 and no charging |

Firmware gates from the official protocol:

- powder-weight command, powder readback, and automatic-mode event/settlement data: beta firmware ≥3.2.4 or release firmware ≥4.0.0;
- shutdown: release firmware ≥4.0.0;
- shutdown is invalid while charging;
- tare is invalid during automatic-mode operation;
- start/stop/reset apply only in timing and ratio modes;
- calibration applies only in weight mode.

## Defects and gaps in the current project

### Must correct

1. **Beep packet is built incorrectly.** The official packet is `03 0A 02 00 <level> checksum`. The mapper currently builds `03 0A 02 <level> 00 checksum`.
2. **Powder weight is missing.** Command `0x0D`, receive type `0x0F`, and ratio-mode settlement parsing are absent.
3. **`FF12` notifications are absent from the reader.** This loses automatic/ratio event traffic demonstrated by the real log.
4. **`0x0D` and `0x0F` decoders are missing.** The first mapper prints them as unknown and tells the user to contact BOOKOO even though both layouts are already published in the official document.
5. **Weight/display-unit labeling is wrong in the mapper.** Display unit and transmitted weight unit are separate facts.
6. **A successful command write is treated too much like success.** Mode restrictions, firmware gates, and actual behavior are not checked.

### Still unknown or unproven

1. How to select timing, automatic, weight, or ratio mode over BLE. No such command appears in the public Ultra protocol.
2. The device's firmware version. The captured GATT reads do not include a firmware revision characteristic.
3. BOOKOO's “Other Data,” which the official document explicitly says is not open.
4. Exact current GATT properties and descriptors saved as a reusable artifact rather than console text.
5. Pairing/bonding requirements across clean Windows installations.
6. Reconnection behavior after radio loss, sleep, shutdown, and application restart.
7. Whether the scale truly allows only one simultaneous client; the current README states this, but this run did not test it.
8. Charging-state data and the exact observable reason a shutdown is rejected while charging.
9. Calibration sequence and reference-mass requirements.

For gaps 1–3 and 8–9, the evidence order should be:

1. ask BOOKOO for the missing protocol/procedure;
2. capture the official Android app with Bluetooth HCI snoop and Wireshark, or use an over-the-air BLE sniffer;
3. compare exact official-app writes with scale notifications;
4. only then add a named command to the custom app—do not infer private command codes by brute force.

## Why STOP can work while the display still flashes

The protocol defines STOP (`0x05`) and RESET (`0x06`) as separate operations. The current reader sends STOP, waits 250 ms, then sends RESET. Therefore:

- if the timer stops advancing after STOP, the communication worked;
- a still-flashing finished/summary display can be a separate scale UI state;
- whether RESET clears the flashing must be tested separately;
- the validator records both telemetry and the user's display observation so these are no longer conflated.

## Validator design

`bookoo_protocol_lab.py` implements a guided, reversible test sequence:

1. capture advertisement data and identify the actual device;
2. connect and persist the complete GATT inventory;
3. verify service `0x0FFE`, receive characteristic `FF11`, command/event characteristic `FF12`, and required properties;
4. subscribe to **all** notify/indicate characteristics, including both `FF11` and `FF12`;
5. log every read, write, notification, checksum result, decoded field, and active test;
6. run individual functional tests with explicit before/after criteria;
7. automatically restore beep, auto-off, and flow-smoothing settings after each test;
8. keep calibration gated because the public procedure is missing;
9. mark unsupported or unproven behavior as `BLOCKED`, `INCONCLUSIVE`, or `TRANSPORT_ONLY`, never as `PASS`;
10. produce `raw_packets.csv`, `session_metadata.json`, `gatt_inventory.json`, `test_results.json`, and a compact `test_results.md` after every run.

Run the tests in this order:

1. baseline connection/GATT/live stream;
2. tare;
3. start/stop/reset;
4. tare + start;
5. beep, auto-off, and flow smoothing with restoration;
6. physical unit switch;
7. powder/ratio and automatic event capture after checking firmware/mode;
8. automatic stop condition;
9. calibration only with the vendor procedure;
10. shutdown last.

## Definition of “complete”

The communication map is complete only when every item is in one of these states:

- **Documented + functionally passed:** ready for production use.
- **Captured from the original app + functionally passed:** usable, with capture provenance retained.
- **Vendor-provided + functionally passed:** usable, with source/version retained.
- **Explicitly unsupported/private:** intentionally excluded and visible as such.

No command should be called complete merely because its bytes can be constructed or the BLE stack accepted the write.
