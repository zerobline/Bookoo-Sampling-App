"""BOOKOO Ultra protocol validator.

This is a guided hardware test tool, not the production reader.  It keeps
three ideas separate:

* a BLE write was accepted (transport proof),
* a documented field changed (protocol proof), and
* the scale really behaved as expected (functional proof).

Protocol source:
    https://github.com/BooKooCode/OpenSource/blob/main/
        bookoo_ultra_scale/protocols.md
    File SHA observed 2026-08-29:
        8dd75655ba5cb0c7188debd17ceab8f8ba39cf62
    Document last update: 2026-08-12

Run:
    py bookoo_protocol_lab.py

Offline checks:
    py bookoo_protocol_lab.py --self-test
    py bookoo_protocol_lab.py --replay protocol_logs/packet_log_....csv
"""

from __future__ import annotations

import argparse
import asyncio
import csv
import importlib.metadata
import json
import platform
import sys
import time
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple


PRODUCT = 0x03
COMMAND_TYPE = 0x0A
LIVE_TYPE = 0x0B
AUTO_EVENT_TYPE = 0x0D
POWDER_TYPE = 0x0F

SERVICE_UUID = "00000ffe-0000-1000-8000-00805f9b34fb"
WEIGHT_CHAR = "0000ff11-0000-1000-8000-00805f9b34fb"
COMMAND_CHAR = "0000ff12-0000-1000-8000-00805f9b34fb"

PROTOCOL_SOURCE = {
    "title": "ULTRA SCALE Transmission protocol",
    "url": (
        "https://github.com/BooKooCode/OpenSource/blob/main/"
        "bookoo_ultra_scale/protocols.md"
    ),
    "file_sha": "8dd75655ba5cb0c7188debd17ceab8f8ba39cf62",
    "document_last_update": "2026-08-12",
    "checked_on": "2026-08-29",
}

EVENT_STATES = {
    0x00: "stopped",
    0x01: "started",
    0x02: "ready",
    0x03: "exit_ready",
    0x04: "exit_done",
}

STATUS_PASS = "PASS"
STATUS_FAIL = "FAIL"
STATUS_INCONCLUSIVE = "INCONCLUSIVE"
STATUS_TRANSPORT = "TRANSPORT_ONLY"
STATUS_NOT_RUN = "NOT_RUN"
STATUS_BLOCKED = "BLOCKED"


@dataclass(frozen=True)
class CommandSpec:
    code: int
    title: str
    parameter: Optional[str] = None
    minimum: Optional[float] = None
    maximum: Optional[float] = None
    persistent: bool = False
    firmware_gate: Optional[str] = None


COMMANDS: Dict[str, CommandSpec] = {
    "tare": CommandSpec(0x01, "Tare"),
    # Official table puts beep level in DATA3 / byte 5, not byte 4.
    "beep": CommandSpec(0x02, "Beep level", "data2", 0, 5, True),
    "autooff": CommandSpec(0x03, "Auto-off minutes", "data2", 5, 30, True),
    "start": CommandSpec(0x04, "Start timer"),
    "stop": CommandSpec(0x05, "Stop timer"),
    "reset": CommandSpec(0x06, "Reset timer"),
    "tarestart": CommandSpec(0x07, "Tare and start timer"),
    "flowsmooth": CommandSpec(0x08, "Flow smoothing", "data1", 0, 1, True),
    "calibrate": CommandSpec(0x09, "Calibration"),
    "stopcondition": CommandSpec(
        0x0B, "Automatic-mode stop condition", "data1", 0, 1, True
    ),
    "powder": CommandSpec(
        0x0D,
        "Set powder weight",
        "powder_x10",
        0.1,
        999.0,
        True,
        "beta >=3.2.4 or release >=4.0.0",
    ),
    "shutdown": CommandSpec(
        0x15,
        "Shutdown",
        firmware_gate="release >=4.0.0; invalid while charging",
    ),
}


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="milliseconds")


def normalize_uuid(value: Any) -> str:
    return str(value).lower()


def hex_bytes(data: Iterable[int]) -> str:
    return " ".join(f"{value:02X}" for value in data)


def xor_checksum(values: Iterable[int]) -> int:
    result = 0
    for value in values:
        result ^= int(value)
    return result


def valid_checksum(data: Sequence[int]) -> bool:
    return len(data) >= 2 and xor_checksum(data[:-1]) == data[-1]


def signed_value(sign: int, magnitude: float) -> float:
    return -magnitude if sign == ord("-") else magnitude


def u16(data: Sequence[int], index: int) -> int:
    return (data[index] << 8) | data[index + 1]


def u24(data: Sequence[int], index: int) -> int:
    return (data[index] << 16) | (data[index + 1] << 8) | data[index + 2]


def build_command(name: str, value: Optional[float] = None) -> bytes:
    """Build one official six-byte command packet with a checked parameter."""
    if name not in COMMANDS:
        raise ValueError(f"Unknown command: {name}")
    spec = COMMANDS[name]
    data1 = 0
    data2 = 0

    if spec.parameter is not None:
        if value is None:
            raise ValueError(f"{name} requires a value")
        if spec.minimum is not None and value < spec.minimum:
            raise ValueError(f"{name} must be >= {spec.minimum}")
        if spec.maximum is not None and value > spec.maximum:
            raise ValueError(f"{name} must be <= {spec.maximum}")

        if spec.parameter == "data1":
            if float(value) != int(value):
                raise ValueError(f"{name} requires an integer")
            data1 = int(value)
        elif spec.parameter == "data2":
            if float(value) != int(value):
                raise ValueError(f"{name} requires an integer")
            data2 = int(value)
        elif spec.parameter == "powder_x10":
            raw = int(round(float(value) * 10))
            data1 = (raw >> 8) & 0xFF
            data2 = raw & 0xFF
        else:
            raise AssertionError(f"Unhandled parameter mapping: {spec.parameter}")

    packet = bytearray([PRODUCT, COMMAND_TYPE, spec.code, data1, data2])
    packet.append(xor_checksum(packet))
    return bytes(packet)


def decode_packet(raw: Sequence[int]) -> Dict[str, Any]:
    """Decode every packet type published by BOOKOO for the Ultra scale."""
    data = bytes(raw)
    base: Dict[str, Any] = {
        "raw_hex": hex_bytes(data),
        "length": len(data),
        "checksum_ok": valid_checksum(data),
    }
    if len(data) < 2:
        base["kind"] = "empty_or_short"
        return base
    base["product"] = data[0]
    base["packet_type"] = data[1]
    if data[0] != PRODUCT:
        base["kind"] = "non_bookoo"
        return base
    if len(data) != 20:
        base["kind"] = "unknown_bookoo_length"
        return base

    packet_type = data[1]
    if packet_type == LIVE_TYPE:
        # The official protocol explicitly says returned weight is always grams.
        base.update(
            {
                "kind": "live",
                "timer_ms": u24(data, 2),
                "timer_s": u24(data, 2) / 1000.0,
                "display_unit_code": data[5],
                "display_unit": {1: "g", 2: "oz"}.get(data[5], "unknown"),
                "weight_g": signed_value(data[6], u24(data, 7) / 100.0),
                "flow_g_s": signed_value(data[10], u16(data, 11) / 100.0),
                "battery_pct": data[13],
                "standby_minutes": u16(data, 14) / 10.0,
                "beep_level": data[16],
                "flow_smoothing": bool(data[17]),
                "reserved_byte": data[18],
            }
        )
    elif packet_type == AUTO_EVENT_TYPE:
        base.update(
            {
                "kind": "automatic_event",
                "event_code": data[2],
                "event": EVENT_STATES.get(data[2], "unknown"),
                "timer_ms": u24(data, 3),
                "timer_s": u24(data, 3) / 1000.0,
                "weight_g": signed_value(data[6], u24(data, 7) / 100.0),
                # Meaning depends on scale mode: average flow in timing mode,
                # liquid/powder ratio in ratio mode.
                "average_flow_or_ratio": signed_value(data[10], u16(data, 11) / 100.0),
            }
        )
    elif packet_type == POWDER_TYPE:
        base.update(
            {
                "kind": "powder_weight",
                "powder_weight_g": signed_value(data[2], u24(data, 3) / 100.0),
            }
        )
    else:
        base["kind"] = "undocumented_bookoo_type"
    return base


@dataclass
class TestResult:
    test_id: str
    title: str
    status: str
    proof: str
    evidence: Dict[str, Any]
    note: str
    recorded_at: str


class SessionWriter:
    def __init__(self, root: Path):
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        self.path = root / f"session_{stamp}"
        self.path.mkdir(parents=True, exist_ok=False)
        self.raw_file = (self.path / "raw_packets.csv").open(
            "w", newline="", encoding="utf-8-sig"
        )
        self.raw_writer = csv.writer(self.raw_file)
        self.raw_writer.writerow(
            [
                "timestamp_utc",
                "monotonic_s",
                "direction",
                "characteristic",
                "active_test",
                "packet_type",
                "checksum_ok",
                "raw_hex",
                "decoded_json",
                "note",
            ]
        )

    def packet(
        self,
        direction: str,
        characteristic: str,
        active_test: str,
        raw: bytes,
        decoded: Dict[str, Any],
        note: str = "",
    ) -> None:
        self.raw_writer.writerow(
            [
                utc_now(),
                f"{time.monotonic():.6f}",
                direction,
                characteristic,
                active_test,
                decoded.get("packet_type", ""),
                decoded.get("checksum_ok", ""),
                hex_bytes(raw),
                json.dumps(decoded, sort_keys=True),
                note,
            ]
        )
        self.raw_file.flush()

    def write_json(self, name: str, value: Any) -> None:
        (self.path / name).write_text(
            json.dumps(value, indent=2, sort_keys=True, default=str) + "\n",
            encoding="utf-8",
        )

    def close(self) -> None:
        if not self.raw_file.closed:
            self.raw_file.close()


class ProtocolLab:
    def __init__(self, output_root: Path, address: Optional[str], scan_seconds: float):
        self.writer = SessionWriter(output_root)
        self.address = address
        self.scan_seconds = scan_seconds
        self.client = None
        self.device = None
        self.advertisement: Dict[str, Any] = {}
        self.gatt: List[Dict[str, Any]] = []
        self.packets: List[Dict[str, Any]] = []
        self.results: List[TestResult] = []
        self.active_test = "baseline"
        self.command_properties: List[str] = []
        self.disconnected = False
        self.finalized = False

    async def ask(self, prompt: str) -> str:
        loop = asyncio.get_running_loop()
        return (await loop.run_in_executor(None, input, prompt)).strip()

    async def confirm(self, prompt: str) -> bool:
        answer = (await self.ask(f"{prompt} [y/N]: ")).lower()
        return answer in {"y", "yes"}

    def result(
        self,
        test_id: str,
        title: str,
        status: str,
        proof: str,
        evidence: Optional[Dict[str, Any]] = None,
        note: str = "",
    ) -> None:
        item = TestResult(
            test_id=test_id,
            title=title,
            status=status,
            proof=proof,
            evidence=evidence or {},
            note=note,
            recorded_at=utc_now(),
        )
        self.results.append(item)
        print(f"\n[{status}] {title}")
        if note:
            print(f"  {note}")

    def latest_live(self) -> Optional[Dict[str, Any]]:
        for packet in reversed(self.packets):
            if packet["decoded"].get("kind") == "live":
                return packet["decoded"]
        return None

    async def wait_packet(self, predicate, start: int, timeout: float):
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            for packet in self.packets[start:]:
                if predicate(packet):
                    return packet
            await asyncio.sleep(0.05)
        return None

    async def wait_live(self, predicate, start: int, timeout: float):
        return await self.wait_packet(
            lambda packet: packet["decoded"].get("kind") == "live"
            and predicate(packet["decoded"]),
            start,
            timeout,
        )

    def notification(self, sender, data: bytearray) -> None:
        raw = bytes(data)
        characteristic = normalize_uuid(getattr(sender, "uuid", sender))
        decoded = decode_packet(raw)
        packet = {
            "timestamp": utc_now(),
            "characteristic": characteristic,
            "raw": raw,
            "decoded": decoded,
        }
        self.packets.append(packet)
        self.writer.packet(
            "RX_NOTIFY", characteristic, self.active_test, raw, decoded
        )
        kind = decoded.get("kind")
        if kind == "automatic_event":
            print(
                f"\n  RX auto event on {characteristic[-12:]}: "
                f"{decoded['event']} t={decoded['timer_s']:.2f}s "
                f"weight={decoded['weight_g']:.2f}g "
                f"result={decoded['average_flow_or_ratio']:.2f}"
            )
        elif kind == "powder_weight":
            print(
                f"\n  RX powder weight on {characteristic[-12:]}: "
                f"{decoded['powder_weight_g']:.2f}g"
            )
        elif kind in {"undocumented_bookoo_type", "unknown_bookoo_length"}:
            print(f"\n  RX undocumented packet: {hex_bytes(raw)}")

    def disconnected_callback(self, _client) -> None:
        self.disconnected = True
        print("\nScale disconnected.")

    async def find_device(self, BleakScanner):
        print(f"Scanning for {self.scan_seconds:.0f} seconds ...")
        discovered = await BleakScanner.discover(
            timeout=self.scan_seconds, return_adv=True
        )
        entries: List[Tuple[Any, Any]] = []
        if isinstance(discovered, dict):
            entries = list(discovered.values())
        else:
            entries = [(device, None) for device in discovered]

        candidates: List[Tuple[Any, Any]] = []
        for device, adv in entries:
            name = (getattr(device, "name", None) or getattr(adv, "local_name", None) or "")
            service_uuids = [normalize_uuid(x) for x in (getattr(adv, "service_uuids", None) or [])]
            if self.address and str(getattr(device, "address", "")).lower() == self.address.lower():
                candidates.append((device, adv))
            elif "BOOKOO" in name.upper() or SERVICE_UUID in service_uuids:
                candidates.append((device, adv))

        if not candidates:
            raise RuntimeError(
                "No BOOKOO candidate found. Turn the scale on, close the phone app, "
                "and make sure Bluetooth is enabled."
            )

        if len(candidates) == 1 or self.address:
            device, adv = candidates[0]
        else:
            print("\nBOOKOO candidates:")
            for index, (candidate, adv_data) in enumerate(candidates, 1):
                name = getattr(candidate, "name", None) or getattr(adv_data, "local_name", None)
                rssi = getattr(adv_data, "rssi", None)
                print(f"  {index}. {name}  {candidate.address}  RSSI={rssi}")
            choice = int(await self.ask("Choose device number: "))
            device, adv = candidates[choice - 1]

        self.device = device
        self.advertisement = {
            "name": getattr(device, "name", None) or getattr(adv, "local_name", None),
            "address": getattr(device, "address", None),
            "rssi": getattr(adv, "rssi", None),
            "service_uuids": list(getattr(adv, "service_uuids", None) or []),
            "manufacturer_data": {
                str(key): hex_bytes(value)
                for key, value in (getattr(adv, "manufacturer_data", None) or {}).items()
            },
            "service_data": {
                str(key): hex_bytes(value)
                for key, value in (getattr(adv, "service_data", None) or {}).items()
            },
        }
        self.result(
            "discovery",
            "BLE discovery",
            STATUS_PASS,
            "captured",
            self.advertisement,
            f"Found {self.advertisement['name']} at {self.advertisement['address']}",
        )
        return device

    async def inspect_gatt(self) -> None:
        service_uuids = set()
        characteristic_map: Dict[str, List[str]] = {}
        print("\nGATT inventory:")
        for service in self.client.services:
            service_uuid = normalize_uuid(service.uuid)
            service_uuids.add(service_uuid)
            service_item = {
                "uuid": service_uuid,
                "description": getattr(service, "description", ""),
                "characteristics": [],
            }
            print(f"  Service {service_uuid}")
            for char in service.characteristics:
                char_uuid = normalize_uuid(char.uuid)
                properties = sorted(str(x) for x in char.properties)
                characteristic_map[char_uuid] = properties
                char_item = {
                    "uuid": char_uuid,
                    "description": getattr(char, "description", ""),
                    "properties": properties,
                    "max_write_without_response_size": getattr(
                        char, "max_write_without_response_size", None
                    ),
                    "descriptors": [
                        {
                            "uuid": normalize_uuid(descriptor.uuid),
                            "handle": getattr(descriptor, "handle", None),
                        }
                        for descriptor in char.descriptors
                    ],
                }
                service_item["characteristics"].append(char_item)
                print(f"    {char_uuid}  {', '.join(properties)}")
                if "read" in properties:
                    try:
                        raw = bytes(await self.client.read_gatt_char(char))
                        decoded = decode_packet(raw)
                        self.writer.packet(
                            "RX_READ",
                            char_uuid,
                            self.active_test,
                            raw,
                            decoded,
                            "initial read",
                        )
                    except Exception as exc:
                        char_item["initial_read_error"] = str(exc)
            self.gatt.append(service_item)

        weight_properties = characteristic_map.get(WEIGHT_CHAR, [])
        self.command_properties = characteristic_map.get(COMMAND_CHAR, [])
        required_ok = (
            SERVICE_UUID in service_uuids
            and bool(weight_properties)
            and bool(self.command_properties)
            and any(x in weight_properties for x in ("notify", "indicate"))
            and any(x in self.command_properties for x in ("write", "write-without-response"))
        )
        self.result(
            "gatt_contract",
            "Required GATT service and characteristics",
            STATUS_PASS if required_ok else STATUS_FAIL,
            "documented + captured",
            {
                "service_present": SERVICE_UUID in service_uuids,
                "weight_properties": weight_properties,
                "command_properties": self.command_properties,
            },
            "0x0FFE / 0xFF11 / 0xFF12 contract verified"
            if required_ok
            else "One or more required UUIDs/properties are missing",
        )
        if not required_ok:
            raise RuntimeError("The connected device does not satisfy the BOOKOO Ultra GATT contract.")

    async def subscribe(self) -> None:
        subscribed = []
        errors = {}
        for service in self.client.services:
            for char in service.characteristics:
                properties = set(str(x) for x in char.properties)
                if not properties.intersection({"notify", "indicate"}):
                    continue
                try:
                    await self.client.start_notify(char, self.notification)
                    subscribed.append(normalize_uuid(char.uuid))
                except Exception as exc:
                    errors[normalize_uuid(char.uuid)] = str(exc)
        both = WEIGHT_CHAR in subscribed and COMMAND_CHAR in subscribed
        self.result(
            "subscriptions",
            "Notification subscriptions",
            STATUS_PASS if WEIGHT_CHAR in subscribed else STATUS_FAIL,
            "captured",
            {"subscribed": subscribed, "errors": errors},
            (
                "Subscribed to FF11 and FF12; automatic/ratio events can be captured"
                if both
                else "FF11 is required; FF12 notifications are needed for observed 0x0D/0x0F events"
            ),
        )

    async def baseline_stream(self) -> None:
        self.active_test = "live_stream"
        start = len(self.packets)
        await asyncio.sleep(2.2)
        live = [
            packet
            for packet in self.packets[start:]
            if packet["decoded"].get("kind") == "live"
        ]
        valid = [packet for packet in live if packet["decoded"].get("checksum_ok")]
        timestamps = [
            datetime.fromisoformat(packet["timestamp"]).timestamp() for packet in valid
        ]
        intervals = [b - a for a, b in zip(timestamps, timestamps[1:])]
        evidence = {
            "live_packets": len(live),
            "valid_packets": len(valid),
            "invalid_packets": len(live) - len(valid),
            "mean_interval_ms": (
                round(sum(intervals) / len(intervals) * 1000, 1) if intervals else None
            ),
            "latest": valid[-1]["decoded"] if valid else None,
        }
        passed = len(valid) >= 5 and len(valid) == len(live)
        self.result(
            "live_stream",
            "Live 0x0B packet stream",
            STATUS_PASS if passed else STATUS_FAIL,
            "captured",
            evidence,
            "Valid live packets received" if passed else "No stable valid live stream",
        )

    async def send(self, name: str, value: Optional[float] = None) -> bytes:
        packet = build_command(name, value)
        spec = COMMANDS[name]
        decoded = {
            "kind": "command",
            "packet_type": COMMAND_TYPE,
            "command": name,
            "command_code": spec.code,
            "value": value,
            "checksum_ok": valid_checksum(packet),
        }
        response = "write" in self.command_properties
        self.writer.packet(
            "TX_WRITE",
            COMMAND_CHAR,
            self.active_test,
            packet,
            decoded,
            spec.title,
        )
        print(f"  TX {name}: {hex_bytes(packet)}")
        await self.client.write_gatt_char(COMMAND_CHAR, packet, response=response)
        return packet

    async def test_tare(self) -> None:
        self.active_test = "tare"
        print("\nTARE TEST")
        print("Place an object of at least 1 g on the scale. Do not touch it afterward.")
        await self.ask("Press Enter when ready ... ")
        before = self.latest_live()
        if before is None or abs(before["weight_g"]) < 1.0:
            start = len(self.packets)
            found = await self.wait_live(lambda item: abs(item["weight_g"]) >= 1.0, start, 5.0)
            before = found["decoded"] if found else self.latest_live()
        start = len(self.packets)
        try:
            await self.send("tare")
        except Exception as exc:
            self.result("tare", "Tare", STATUS_FAIL, "transport", note=str(exc))
            return
        zero = await self.wait_live(lambda item: abs(item["weight_g"]) <= 0.30, start, 3.0)
        proven = before is not None and abs(before["weight_g"]) >= 1.0 and zero is not None
        self.result(
            "tare",
            "Tare",
            STATUS_PASS if proven else STATUS_INCONCLUSIVE,
            "functional" if proven else "transport",
            {
                "before_weight_g": before.get("weight_g") if before else None,
                "after_weight_g": zero["decoded"]["weight_g"] if zero else None,
            },
            "Weight changed from a non-zero load to approximately zero"
            if proven
            else "Write succeeded, but the precondition/readback did not prove tare",
        )

    async def test_timer(self) -> None:
        self.active_test = "timer_start_stop_reset"
        print("\nTIMER TEST")
        try:
            start = len(self.packets)
            await self.send("reset")
            reset_before = await self.wait_live(lambda item: item["timer_s"] <= 0.20, start, 2.0)

            start = len(self.packets)
            await self.send("start")
            running = await self.wait_live(lambda item: item["timer_s"] >= 0.60, start, 2.5)

            await self.send("stop")
            await asyncio.sleep(0.35)
            stopped_a = self.latest_live()
            await asyncio.sleep(1.1)
            stopped_b = self.latest_live()
            stable = bool(
                stopped_a
                and stopped_b
                and abs(stopped_b["timer_s"] - stopped_a["timer_s"]) <= 0.15
            )
            flashing_after_stop = await self.confirm(
                "After STOP, is the scale display still flashing?"
            )

            start = len(self.packets)
            await self.send("reset")
            reset_after = await self.wait_live(lambda item: item["timer_s"] <= 0.20, start, 2.0)
            flashing_after_reset = await self.confirm(
                "After RESET, is the scale display still flashing?"
            )
        except Exception as exc:
            self.result(
                "timer", "Start / stop / reset timer", STATUS_FAIL, "transport", note=str(exc)
            )
            return

        passed = bool(reset_before and running and stable and reset_after)
        note = (
            "Timer start, stop and reset were proven. STOP flashing is a display-state "
            "behavior, not a failed stop; RESET is the separate command that clears it."
            if passed
            else "At least one timer transition was not proven from live telemetry."
        )
        self.result(
            "timer",
            "Start / stop / reset timer",
            STATUS_PASS if passed else STATUS_FAIL,
            "functional",
            {
                "reset_before": bool(reset_before),
                "running_timer_s": running["decoded"]["timer_s"] if running else None,
                "stopped_timer_first_s": stopped_a.get("timer_s") if stopped_a else None,
                "stopped_timer_later_s": stopped_b.get("timer_s") if stopped_b else None,
                "stable_after_stop": stable,
                "reset_after": bool(reset_after),
                "display_flashing_after_stop": flashing_after_stop,
                "display_flashing_after_reset": flashing_after_reset,
            },
            note,
        )

    async def test_tarestart(self) -> None:
        self.active_test = "tarestart"
        print("\nTARE + START TEST")
        print("Put an object on the scale, then leave it untouched.")
        await self.ask("Press Enter when ready ... ")
        start = len(self.packets)
        try:
            await self.send("tarestart")
            proof = await self.wait_live(
                lambda item: abs(item["weight_g"]) <= 0.30 and item["timer_s"] >= 0.60,
                start,
                3.0,
            )
            await self.send("stop")
            await asyncio.sleep(0.25)
            await self.send("reset")
        except Exception as exc:
            self.result(
                "tarestart", "Tare + start", STATUS_FAIL, "transport", note=str(exc)
            )
            return
        self.result(
            "tarestart",
            "Tare + start",
            STATUS_PASS if proof else STATUS_INCONCLUSIVE,
            "functional" if proof else "transport",
            proof["decoded"] if proof else {},
            "Both zeroed weight and advancing timer observed"
            if proof
            else "Write succeeded, but both effects were not observed together",
        )

    async def test_setting(
        self,
        test_id: str,
        title: str,
        command: str,
        field: str,
        original: Any,
        trial: Any,
        compare,
    ) -> None:
        self.active_test = test_id
        if not await self.confirm(
            f"Temporarily change {title} from {original} to {trial}, then restore it?"
        ):
            self.result(test_id, title, STATUS_NOT_RUN, "none", note="User skipped test")
            return
        changed = None
        restored = None
        error = None
        try:
            start = len(self.packets)
            await self.send(command, trial)
            changed = await self.wait_live(
                lambda item: compare(item.get(field), trial), start, 3.0
            )
        except Exception as exc:
            error = str(exc)
        finally:
            try:
                start = len(self.packets)
                await self.send(command, original)
                restored = await self.wait_live(
                    lambda item: compare(item.get(field), original), start, 3.0
                )
            except Exception as exc:
                error = f"{error or ''} restore failed: {exc}".strip()
        passed = bool(changed and restored and not error)
        self.result(
            test_id,
            title,
            STATUS_PASS if passed else STATUS_FAIL,
            "functional",
            {
                "original": original,
                "trial": trial,
                "changed_readback": changed["decoded"].get(field) if changed else None,
                "restored_readback": restored["decoded"].get(field) if restored else None,
                "error": error,
            },
            "Setting changed in telemetry and was restored"
            if passed
            else "Setting change or restoration was not proven",
        )

    async def test_beep(self) -> None:
        live = self.latest_live()
        if not live:
            self.result("beep", "Beep level", STATUS_BLOCKED, "none", note="No live packet")
            return
        original = int(live["beep_level"])
        trial = original - 1 if original == 5 else original + 1
        await self.test_setting(
            "beep",
            "Beep level (correct command byte)",
            "beep",
            "beep_level",
            original,
            trial,
            lambda actual, expected: actual == expected,
        )

    async def test_autooff(self) -> None:
        live = self.latest_live()
        if not live:
            self.result("autooff", "Auto-off", STATUS_BLOCKED, "none", note="No live packet")
            return
        original_float = float(live["standby_minutes"])
        original = int(round(original_float))
        if not (5 <= original <= 30) or abs(original_float - original) > 0.01:
            self.result(
                "autooff",
                "Auto-off minutes",
                STATUS_BLOCKED,
                "captured",
                {"observed": original_float},
                "Observed value cannot be safely restored as an official integer setting",
            )
            return
        trial = original - 1 if original == 30 else original + 1
        await self.test_setting(
            "autooff",
            "Auto-off minutes",
            "autooff",
            "standby_minutes",
            original,
            trial,
            lambda actual, expected: actual is not None and abs(actual - expected) < 0.01,
        )

    async def test_flow_smoothing(self) -> None:
        live = self.latest_live()
        if not live:
            self.result(
                "flowsmooth", "Flow smoothing", STATUS_BLOCKED, "none", note="No live packet"
            )
            return
        original = int(bool(live["flow_smoothing"]))
        trial = 1 - original
        await self.test_setting(
            "flowsmooth",
            "Flow smoothing",
            "flowsmooth",
            "flow_smoothing",
            original,
            trial,
            lambda actual, expected: actual is not None and int(bool(actual)) == expected,
        )

    async def test_physical_unit(self) -> None:
        self.active_test = "display_unit"
        live = self.latest_live()
        if not live:
            self.result(
                "display_unit", "Physical display-unit switch", STATUS_BLOCKED, "none", note="No live packet"
            )
            return
        original = live["display_unit_code"]
        print(
            f"\nCurrent display-unit code is {original} ({live['display_unit']}). "
            "The public protocol has no command for changing it."
        )
        start = len(self.packets)
        await self.ask("Change the unit on the physical scale, then press Enter ... ")
        changed = await self.wait_live(
            lambda item: item["display_unit_code"] != original, start, 3.0
        )
        if changed:
            changed_code = changed["decoded"]["display_unit_code"]
            restore_start = len(self.packets)
            await self.ask("Change the physical unit back, then press Enter ... ")
            restored = await self.wait_live(
                lambda item: item["display_unit_code"] == original, restore_start, 3.0
            )
        else:
            changed_code = None
            restored = None
        self.result(
            "display_unit",
            "Physical display-unit switch",
            STATUS_PASS if changed and restored else STATUS_INCONCLUSIVE,
            "functional" if changed else "captured",
            {
                "original_code": original,
                "changed_code": changed_code,
                "restored": bool(restored),
                "important": "weight field remains grams even when display_unit is oz",
            },
            "Unit byte changed and was restored"
            if changed and restored
            else "No public BLE unit command exists; physical change was not fully proven",
        )

    async def test_powder_ratio(self) -> None:
        self.active_test = "powder_ratio"
        print("\nPOWDER / RATIO TEST")
        print(
            "Requires beta firmware >=3.2.4 or release firmware >=4.0.0. "
            "The public protocol does not include a command that selects ratio mode."
        )
        if not await self.confirm("Is the scale already in ratio mode and ready to test?"):
            self.result(
                "powder_ratio",
                "Powder weight / ratio support",
                STATUS_BLOCKED,
                "documented",
                note="Ratio-mode selection is not exposed in the public protocol",
            )
            return
        try:
            value = float(await self.ask("Powder weight to send in grams (for example 18.0): "))
        except ValueError:
            self.result(
                "powder_ratio", "Powder weight / ratio support", STATUS_NOT_RUN, "none", note="Invalid number"
            )
            return
        start = len(self.packets)
        try:
            await self.send("powder", value)
        except Exception as exc:
            self.result(
                "powder_ratio", "Powder weight / ratio support", STATUS_FAIL, "transport", note=str(exc)
            )
            return
        powder = await self.wait_packet(
            lambda packet: packet["decoded"].get("kind") == "powder_weight"
            and abs(packet["decoded"]["powder_weight_g"] - value) <= 0.11,
            start,
            4.0,
        )
        display = await self.confirm("Did the scale accept/show the powder weight?")
        passed = bool(powder or display)
        self.result(
            "powder_ratio",
            "Powder weight / ratio support",
            STATUS_PASS if passed else STATUS_INCONCLUSIVE,
            "functional" if passed else "transport",
            {
                "sent_weight_g": value,
                "0x0F_readback": powder["decoded"] if powder else None,
                "display_confirmed": display,
            },
            "Powder setting was functionally observed"
            if passed
            else "Write succeeded, but firmware/mode/readback support was not proven",
        )

    async def capture_auto_ratio_events(self) -> None:
        self.active_test = "auto_ratio_capture"
        print("\nAUTOMATIC / RATIO EVENT CAPTURE")
        print(
            "Operate one complete ready -> start -> stop -> exit cycle on the scale. "
            "Notifications continue while this prompt is open."
        )
        start = len(self.packets)
        await self.ask("Press Enter after the full cycle is finished ... ")
        captured = [
            packet["decoded"]
            for packet in self.packets[start:]
            if packet["decoded"].get("kind") in {"automatic_event", "powder_weight"}
        ]
        event_names = [item.get("event") for item in captured if item.get("kind") == "automatic_event"]
        passed = any(name in event_names for name in ("started", "stopped"))
        self.result(
            "auto_ratio_capture",
            "Automatic / ratio event cycle",
            STATUS_PASS if passed else STATUS_INCONCLUSIVE,
            "captured",
            {"packets": captured, "event_sequence": event_names},
            "0x0D/0x0F event traffic captured"
            if captured
            else "No 0x0D/0x0F packets were observed",
        )

    async def test_stop_condition(self) -> None:
        self.active_test = "stop_condition"
        print("\nAUTOMATIC STOP-CONDITION TEST")
        print(
            "This setting has no published readback field, so a successful write is not proof. "
            "The behavior must be tested in automatic mode. The previous value cannot be read/restored."
        )
        if not await self.confirm("Continue and intentionally set a new stop condition?"):
            self.result(
                "stop_condition", "Automatic stop condition", STATUS_NOT_RUN, "none", note="User skipped test"
            )
            return
        choice = await self.ask("Enter 0 (flow stops) or 1 (container removed): ")
        if choice not in {"0", "1"}:
            self.result(
                "stop_condition", "Automatic stop condition", STATUS_NOT_RUN, "none", note="Invalid selection"
            )
            return
        try:
            await self.send("stopcondition", int(choice))
        except Exception as exc:
            self.result(
                "stop_condition", "Automatic stop condition", STATUS_FAIL, "transport", note=str(exc)
            )
            return
        confirmed = await self.confirm(
            "After running an automatic-mode trial, did it stop by the selected condition?"
        )
        self.result(
            "stop_condition",
            "Automatic stop condition",
            STATUS_PASS if confirmed else STATUS_TRANSPORT,
            "functional" if confirmed else "transport",
            {"selected": int(choice), "user_confirmed_behavior": confirmed},
            "Behavior confirmed"
            if confirmed
            else "BLE write succeeded; functional effect remains unproven",
        )

    async def calibration_gate(self) -> None:
        self.active_test = "calibration"
        print("\nCALIBRATION (HIGH CONSEQUENCE)")
        print(
            "BOOKOO publishes the command byte but not the calibration procedure or required mass. "
            "Sending it without the correct procedure can invalidate measurements."
        )
        phrase = await self.ask(
            "Type CALIBRATE only if you have BOOKOO's procedure and the specified weight; otherwise Enter: "
        )
        if phrase != "CALIBRATE":
            self.result(
                "calibration",
                "Calibration command",
                STATUS_BLOCKED,
                "documented",
                note="Command mapped; functional test withheld until the vendor procedure is available",
            )
            return
        try:
            await self.send("calibrate")
        except Exception as exc:
            self.result(
                "calibration", "Calibration command", STATUS_FAIL, "transport", note=str(exc)
            )
            return
        confirmed = await self.confirm("Did the documented calibration procedure complete successfully?")
        self.result(
            "calibration",
            "Calibration command",
            STATUS_PASS if confirmed else STATUS_TRANSPORT,
            "functional" if confirmed else "transport",
            {"user_confirmed": confirmed},
            "Calibration confirmed" if confirmed else "Write accepted; calibration not proven",
        )

    async def test_shutdown(self) -> None:
        self.active_test = "shutdown"
        print("\nSHUTDOWN TEST")
        print("Requires release firmware >=4.0.0 and does not work while charging.")
        if not await self.confirm("Send shutdown now? This will end the session if it works."):
            self.result("shutdown", "Shutdown", STATUS_NOT_RUN, "none", note="User skipped test")
            return
        try:
            await self.send("shutdown")
            deadline = time.monotonic() + 5.0
            while time.monotonic() < deadline and not self.disconnected:
                await asyncio.sleep(0.1)
        except Exception as exc:
            self.result("shutdown", "Shutdown", STATUS_FAIL, "transport", note=str(exc))
            return
        powered_off = await self.confirm("Did the scale power off?")
        passed = self.disconnected and powered_off
        self.result(
            "shutdown",
            "Shutdown",
            STATUS_PASS if passed else STATUS_INCONCLUSIVE,
            "functional" if passed else "transport",
            {"disconnected": self.disconnected, "power_off_confirmed": powered_off},
            "Scale powered off and disconnected"
            if passed
            else "Firmware, charging state, or behavior prevented complete proof",
        )

    def print_menu(self) -> None:
        print(
            """
\nChoose a test
  1  Tare
  2  Start / stop / reset timer (also records flashing)
  3  Combined tare + start
  4  Beep level (temporarily changes and restores)
  5  Auto-off minutes (temporarily changes and restores)
  6  Flow smoothing (temporarily changes and restores)
  7  Physical g/oz unit switch (no public BLE command)
  8  Set powder weight / ratio support
  9  Capture one automatic/ratio event cycle
 10  Automatic stop condition (behavioral test)
 11  Calibration (gated; vendor procedure required)
 12  Shutdown (run last)
  R  Show results so far
  Q  Save report and disconnect
"""
        )

    def show_results(self) -> None:
        print("\nResults:")
        for result in self.results:
            print(f"  {result.status:16} {result.title}")

    async def menu(self) -> None:
        actions = {
            "1": self.test_tare,
            "2": self.test_timer,
            "3": self.test_tarestart,
            "4": self.test_beep,
            "5": self.test_autooff,
            "6": self.test_flow_smoothing,
            "7": self.test_physical_unit,
            "8": self.test_powder_ratio,
            "9": self.capture_auto_ratio_events,
            "10": self.test_stop_condition,
            "11": self.calibration_gate,
            "12": self.test_shutdown,
        }
        while not self.disconnected:
            self.print_menu()
            choice = (await self.ask("Selection: ")).lower()
            if choice == "q":
                break
            if choice == "r":
                self.show_results()
                continue
            action = actions.get(choice)
            if action is None:
                print("Unknown selection.")
                continue
            try:
                await action()
            except Exception as exc:
                self.result(
                    f"unexpected_{choice}",
                    "Unexpected test error",
                    STATUS_FAIL,
                    "none",
                    note=str(exc),
                )

    def finalize(self) -> None:
        if self.finalized:
            return
        metadata = {
            "protocol_source": PROTOCOL_SOURCE,
            "created_at_utc": utc_now(),
            "platform": platform.platform(),
            "python": sys.version,
            "bleak": package_version("bleak"),
            "device": self.advertisement,
            "mtu_size": getattr(self.client, "mtu_size", None) if self.client else None,
            "packet_count": len(self.packets),
        }
        self.writer.write_json("session_metadata.json", metadata)
        self.writer.write_json("gatt_inventory.json", self.gatt)
        self.writer.write_json("test_results.json", [asdict(item) for item in self.results])

        lines = [
            "# BOOKOO Ultra protocol test results",
            "",
            f"Created: {metadata['created_at_utc']}",
            f"Device: {self.advertisement.get('name', 'unknown')}",
            f"Packets captured: {len(self.packets)}",
            "",
            "| Status | Test | Proof | Note |",
            "|---|---|---|---|",
        ]
        for item in self.results:
            note = item.note.replace("|", "\\|").replace("\n", " ")
            lines.append(f"| {item.status} | {item.title} | {item.proof} | {note} |")
        lines.extend(
            [
                "",
                "A successful BLE write is recorded as transport proof only. A PASS requires "
                "telemetry, an event packet, or a deliberate human observation showing the effect.",
                "",
            ]
        )
        (self.writer.path / "test_results.md").write_text("\n".join(lines), encoding="utf-8")
        self.writer.close()
        self.finalized = True

    async def run(self) -> None:
        try:
            from bleak import BleakClient, BleakScanner
        except ImportError as exc:
            version = package_version("bleak")
            interpreter = sys.executable
            try:
                import bleak

                source = getattr(bleak, "__file__", "unknown")
            except Exception:
                source = "not importable"
            raise RuntimeError(
                "Bleak is installed but its Bluetooth classes could not be imported. "
                f"Original error: {exc!r}. Python={interpreter}, "
                f"detected version={version}, source={source}. "
                "Run: py -m pip install --upgrade --force-reinstall \"bleak>=1.0\". "
                "If it still fails, make sure there is no bleak.py file or bleak folder "
                "beside this script."
            ) from exc

        device = await self.find_device(BleakScanner)
        print(f"Connecting to {self.advertisement.get('name')} ...")
        try:
            async with BleakClient(
                device, timeout=15.0, disconnected_callback=self.disconnected_callback
            ) as client:
                self.client = client
                self.result(
                    "connection",
                    "BLE connection",
                    STATUS_PASS,
                    "captured",
                    {"is_connected": client.is_connected},
                    "Connected",
                )
                await self.inspect_gatt()
                await self.subscribe()
                await self.baseline_stream()
                await self.menu()
        finally:
            self.finalize()
            print(f"\nReport saved to: {self.writer.path}")


def package_version(name: str) -> Optional[str]:
    try:
        return importlib.metadata.version(name)
    except importlib.metadata.PackageNotFoundError:
        return None


def parse_mapper_csv(path: Path) -> Dict[str, Any]:
    rows = []
    with path.open("r", newline="", encoding="utf-8-sig") as handle:
        for row in csv.DictReader(handle):
            raw_hex = (row.get("raw_hex") or "").strip()
            raw = bytes(int(item, 16) for item in raw_hex.split()) if raw_hex else b""
            rows.append(
                {
                    "timestamp": row.get("timestamp"),
                    "characteristic": normalize_uuid(row.get("characteristic", "")),
                    "note": row.get("note", ""),
                    "raw": raw,
                    "decoded": decode_packet(raw),
                }
            )
    bookoo = [row for row in rows if row["decoded"].get("product") == PRODUCT]
    counts: Dict[str, int] = {}
    by_characteristic: Dict[str, int] = {}
    for row in bookoo:
        kind = row["decoded"].get("kind", "unknown")
        counts[kind] = counts.get(kind, 0) + 1
        key = f"{row['characteristic']} / {kind}"
        by_characteristic[key] = by_characteristic.get(key, 0) + 1
    invalid = [row for row in bookoo if not row["decoded"].get("checksum_ok")]
    events = [
        {
            "timestamp": row["timestamp"],
            "characteristic": row["characteristic"],
            "decoded": row["decoded"],
        }
        for row in bookoo
        if row["decoded"].get("kind") in {"automatic_event", "powder_weight"}
    ]
    return {
        "file": str(path),
        "rows": len(rows),
        "bookoo_packets": len(bookoo),
        "packet_kinds": counts,
        "by_characteristic": by_characteristic,
        "invalid_bookoo_checksums": len(invalid),
        "automatic_or_powder_events": events,
    }


def run_self_test() -> None:
    expected = {
        ("tare", None): "03 0A 01 00 00 08",
        ("beep", 5): "03 0A 02 00 05 0E",
        ("autooff", 15): "03 0A 03 00 0F 05",
        ("start", None): "03 0A 04 00 00 0D",
        ("stop", None): "03 0A 05 00 00 0C",
        ("reset", None): "03 0A 06 00 00 0F",
        ("tarestart", None): "03 0A 07 00 00 0E",
        ("flowsmooth", 1): "03 0A 08 01 00 00",
        ("calibrate", None): "03 0A 09 00 00 00",
        ("stopcondition", 1): "03 0A 0B 01 00 03",
        ("powder", 18.0): "03 0A 0D 00 B4 B0",
        ("shutdown", None): "03 0A 15 00 00 1C",
    }
    for (name, value), packet_hex in expected.items():
        packet = build_command(name, value)
        assert hex_bytes(packet) == packet_hex, (name, hex_bytes(packet), packet_hex)
        assert valid_checksum(packet)

    live = bytes.fromhex(
        "03 0B 00 00 00 01 2B 00 00 00 2D 00 01 50 00 96 01 00 00 C9"
    )
    decoded = decode_packet(live)
    assert decoded["kind"] == "live"
    assert decoded["weight_g"] == 0.0
    assert decoded["flow_g_s"] == -0.01
    assert decoded["battery_pct"] == 80
    assert decoded["standby_minutes"] == 15.0
    assert decoded["beep_level"] == 1
    assert decoded["flow_smoothing"] is False

    event = bytes.fromhex(
        "03 0D 01 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 0F"
    )
    event_decoded = decode_packet(event)
    assert event_decoded["kind"] == "automatic_event"
    assert event_decoded["event"] == "started"

    powder = bytearray([PRODUCT, POWDER_TYPE, ord("+"), 0x00, 0x07, 0x08])
    powder.extend([0x00] * (19 - len(powder)))
    powder.append(xor_checksum(powder))
    powder_decoded = decode_packet(powder)
    assert powder_decoded["kind"] == "powder_weight"
    assert powder_decoded["powder_weight_g"] == 18.0
    print(f"PASS: {len(expected)} command fixtures and 3 receive-packet fixtures")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Guided BOOKOO Ultra BLE protocol validator")
    parser.add_argument("--self-test", action="store_true", help="run offline protocol fixtures")
    parser.add_argument("--replay", type=Path, help="analyze a packet_log CSV without hardware")
    parser.add_argument("--address", help="use this BLE address when several scales are nearby")
    parser.add_argument("--scan-seconds", type=float, default=7.0)
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=Path(__file__).resolve().parent / "protocol_sessions",
    )
    return parser


def main() -> int:
    args = build_parser().parse_args()
    if args.self_test:
        run_self_test()
        return 0
    if args.replay:
        print(json.dumps(parse_mapper_csv(args.replay), indent=2, default=str))
        return 0

    lab = ProtocolLab(args.output_dir, args.address, args.scan_seconds)
    try:
        asyncio.run(lab.run())
    except KeyboardInterrupt:
        print("\nInterrupted.")
        lab.finalize()
        return 130
    except Exception as exc:
        print(f"\nERROR: {exc}")
        lab.finalize()
        print(f"Partial report saved to: {lab.writer.path}")
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
